import {
  Component,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { BiColumnComponent } from '../bi-column/bi-column.component';

@Component({
  selector: 'bi-columns',
  templateUrl: './bi-columns.component.html',
  styleUrls: ['./bi-columns.component.scss'],
})
export class BiColumnsComponent {
  constructor() {}

  ngOnInit(): void {}
}
